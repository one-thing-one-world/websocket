## 服务端事件
1. 登录成功: loginSuccess
2. 登录失败: loginError
3. 获取用户列表: userList
4. 用户下线: delUser
5. 获取所有消息: receiveMessage

## 客户端事件
1. 登录: login
2. 发送信息: sendMessage